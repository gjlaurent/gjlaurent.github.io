function stop = plotCouverture(V, optimValues, state)

persistent img;
persistent controlPointX;
persistent controlPointY;

switch state
    case 'init'
        % Setup for plots or guis
        
        img=imread('besancon.png');
        load besancon.mat
        
    case 'iter'
        % Make updates to plot or guis as needed
        
        X=V(1:2:length(V));
        Y=V(2:2:length(V));
        
        image(img);
        axis image;
        hold on;
        
        plot(controlPointX,controlPointY,'w.');
        
        plot(X,Y,'r.')
        for i=1:1:length(X)
            plotCircle(X(i),Y(i),10,20,'r');
            plotCircle(X(i),Y(i),20,30,'r');
            plotCircle(X(i),Y(i),50,30,'r');
            set(text(X(i)+35,Y(i)+35,num2str(i)),'color','r');
        end
        title('Current X Value');
        
        hold off;
        
        
    case 'interrupt'
        % Probably no action here. Check conditions to see
        % whether optimization should quit.
        
    case 'done'
        % Cleanup of plots, guis, or final plot
        
    otherwise
        
end

stop=false;

end

