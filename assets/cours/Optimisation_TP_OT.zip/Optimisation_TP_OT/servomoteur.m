function [J,J1,J2]=servomoteur(X,alpha)

kp=X(1);
kd=X(2);

load_system('simServomoteur');
set_param('simServomoteur/PID Controller', 'P', num2str(kp) );
set_param('simServomoteur/PID Controller', 'D', num2str(kd) );

simOut = sim('simServomoteur', 'ReturnWorkspaceOutputs', 'on');

error=simOut.get('error');
voltage=simOut.get('voltage');

J=(1-alpha)*error(length(error))+alpha*voltage(length(voltage))/1000;

end