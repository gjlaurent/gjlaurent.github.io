function Q=couverture(V)


X=V(1:2:length(V));
Y=V(2:2:length(V));

load Besancon.mat

D=zeros(length(controlPointX),length(X));

for i=1:1:length(X)
    D(:,i)=sqrt((controlPointX-X(i)).^2+(controlPointY-Y(i)).^2);
end

Q=sum(softmax(D,-1))/length(controlPointX);

end