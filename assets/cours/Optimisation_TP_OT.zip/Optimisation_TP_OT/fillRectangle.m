function [X,Y] = fillRectangle(x,y,alpha,long,larg,col)
% fill a rectangle
%
% [X,Y] = fillRectangle(x,y,alpha,long,larg,col)
%   

X=zeros(5,1);
Y=zeros(5,1);
long=.5*long;
larg=.5*larg;

X(1)=x+long*cos(alpha)-larg*sin(alpha);
X(2)=x-long*cos(alpha)-larg*sin(alpha);
X(3)=x-long*cos(alpha)+larg*sin(alpha);
X(4)=x+long*cos(alpha)+larg*sin(alpha);
X(5)=X(1);

Y(1)=y+long*sin(alpha)+larg*cos(alpha);
Y(2)=y-long*sin(alpha)+larg*cos(alpha);
Y(3)=y-long*sin(alpha)-larg*cos(alpha);
Y(4)=y+long*sin(alpha)-larg*cos(alpha);
Y(5)=Y(1);

fill(X,Y,col);
end

