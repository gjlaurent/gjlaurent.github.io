function stop = plotServomoteur(X, optimValues, state)

switch state
    case 'init'
        % Setup for plots or guis
        
    case 'iter'
        % Make updates to plot or guis as needed
        
        kp=X(1);
        kd=X(2);
        
        load_system('simServomoteur');
        set_param('simServomoteur/PID Controller', 'P', num2str(kp) );
        set_param('simServomoteur/PID Controller', 'D', num2str(kd) );
        
        simOut = sim('simServomoteur', 'ReturnWorkspaceOutputs', 'on');
        
        error=simOut.get('error');
        voltage=simOut.get('voltage');
        position=simOut.get('position');
        time=simOut.get('time');
        
        J1=error(length(error));
        J2=voltage(length(voltage))/1000;
        
        plot(time,position,'r');
        grid on;
        xlabel('Time');
        ylabel('Position');
        title(['Current X Value: [' num2str(kp) ' ' num2str(kd) '], J_1: ' num2str(J1) ', J_2: ' num2str(J2) ]);
        
        
    case 'interrupt'
        % Probably no action here. Check conditions to see
        % whether optimization should quit.
        
    case 'done'
        % Cleanup of plots, guis, or final plot
        
    otherwise
        
end

stop=false;

end
