function [X,Y] = plotCircle(x,y,r,n,options)
% plot a circle 
%
% [X,Y] = plotCircle(x,y,r,n,options)
%   


a=0:2*pi/(n-1):2*pi;
X=x+r*cos(a);
Y=y+r*sin(a);
plot(X,Y,options);
end

