function stop = plotFunctionDifference(X, optimValues, state)
% plotFunctionDifference plots the absolute value of the difference of 
%   function values between two iterations: abs(f(X_k)-f(X_{k-1}).
%
%   Usage: 
%     Create an options structure that will use plotFunctionDifference as
%     the plot function:
%
%       options = optimset('PlotFcns',@plotFunctionDifference);
%
%     Pass the options into an optimization problem to view the plot.

%   Copyright 2014 Guillaume Laurent

persistent previousfval;

switch state
    case 'init'
          % Setup for plots or guis

          previousfval=optimValues.fval;
          xlabel('Iteration');
          ylabel('Function Difference');
          set(gca,'YScale','log'); 
          grid on;
          hold on;     
           
    case 'iter'
          % Make updates to plot or guis as needed
          
          semilogy(optimValues.iteration,abs(optimValues.fval-previousfval),'.r');
          title(['Current Function Difference: ' num2str(abs(optimValues.fval-previousfval))]);
          previousfval=optimValues.fval;
         
    case 'interrupt'
          % Probably no action here. Check conditions to see  
          % whether optimization should quit.

    case 'done'
          % Cleanup of plots, guis, or final plot

         
    otherwise
        
end

stop=false;

end
