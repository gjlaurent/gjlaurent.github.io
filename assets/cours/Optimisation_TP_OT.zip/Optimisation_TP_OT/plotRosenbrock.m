function stop = plotRosenbrock(X, optimValues, state)

persistent previousX;

switch state
    case 'init'
          % Setup for plots or guis
          
          cla reset;
          x=-3:.02:2;
          y=-1:.02:3;
          [xx,yy]=meshgrid(x,y);
          zz=100*(yy-xx.^2).^2+(1-xx).^2;
          surface(x,y,zz,'EdgeColor','none');
          view(0,90);
          xlabel('x');
          ylabel('y');
          axis equal;
          axis([-3 2 -1 3]);
          hsv2=hsv;
          hsv3=[hsv2(11:64,:); hsv2(1:10,:)];
          colormap(hsv3);
          hold on;
 
    case 'iter'
          % Make updates to plot or guis as needed
          
          plot3(X(1),X(2),10000,'ro', ...
              'MarkerSize',5, ...
              'EraseMode','none');
          if isfield(optimValues,'searchdirection') & length(optimValues.searchdirection)==2
                plot3([X(1) previousX(1)],[X(2) previousX(2)],[10000 10000],'r');
          end
        title(['Current X Value: [' num2str(X(1)) ' ' num2str(X(2)) ']']);
          previousX=X;
          
    case 'interrupt'
          % Probably no action here. Check conditions to see  
          % whether optimization should quit.

    case 'done'
          % Cleanup of plots, guis, or final plot

    otherwise
        
end

stop=false;

end
