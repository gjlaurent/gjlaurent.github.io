function stop = plotFunctionValue(X, optimValues, state)
% plotFunctionValue plots the value of the function at each iteration: f(X_k).
%
%   Usage: 
%     Create an options structure that will use plotFunctionValue as
%     the plot function:
%
%       options = optimset('PlotFcns',@plotFunctionValue);
%
%     Pass the options into an optimization problem to view the plot.

%   Copyright 2014 Guillaume Laurent

switch state
    
    case 'init'
          % Setup for plots or guis
          
          semilogy(optimValues.iteration,optimValues.fval,'.r');
          xlabel('Iteration');
          ylabel('Function Value');
          set(gca,'YScale','log'); 
          grid on;
          hold on;     
           
    case 'iter'
          % Make updates to plot or guis as needed
          
          semilogy(optimValues.iteration,optimValues.fval,'.r');
          title(['Current Function Value: ' num2str(optimValues.fval)]);
         
    case 'interrupt'
          % Probably no action here. Check conditions to see  
          % whether optimization should quit.

    case 'done'
          % Cleanup of plots, guis, or final plot
 
    otherwise
        
end

stop=false;

end
