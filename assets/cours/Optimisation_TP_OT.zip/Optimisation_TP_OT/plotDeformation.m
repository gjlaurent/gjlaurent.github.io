function stop = plotDeformation(P, optimValues, state)

switch state
    case 'init'
        % Setup for plots or guis
        
    case 'iter'
        % Make updates to plot or guis as needed
        
        x4=P(1);
        z4=P(2);
        z5=P(3);
        
        X=[10 20 30 x4 20 40-x4  0  0  40 40];
        Z=[20 20 20 z4 z5 z4 20  10 20 10];
        
        M=[0 1 0 1 1 0 1 1 0 0
            1 0 1 1 1 1 0 0 0 0
            0 1 0 0 1 1 0 0 1 1
            1 1 0 0 1 0 1 1 0 0
            1 1 1 1 0 1 0 0 0 0
            0 1 1 0 1 0 0 0 1 1
            1 0 0 1 0 0 0 0 0 0
            1 0 0 1 0 0 0 0 0 0
            0 0 1 0 0 1 0 0 0 0
            0 0 1 0 0 1 0 0 0 0];
        
        fillRectangle(-5,10,0,10,20,[.5 .5 .5]);
        axis([-10 50 0 40]);
        hold on;
        xlabel('x');
        ylabel('z');
        title('Current X Value');
        fillRectangle(45,10,0,10,20,[.5 .5 .5]);
        
        for i=1:1:10
            plot(X(i),Z(i),'b.');
            for j=i:1:10
                if M(i,j)==1
                    plot([X(i) X(j)],[Z(i) Z(j)]);
                end
            end
        end
        
        text(X(1),Z(1)+1,'1');
        text(X(2),Z(2)+1,'2');
        text(X(3),Z(3)+1,'3');
        text(X(4),Z(4)-1,'4');
        text(X(5),Z(5)-1,'5');
        text(X(6),Z(6)-1,'6');
        
        hold off;
        
    case 'interrupt'
        % Probably no action here. Check conditions to see
        % whether optimization should quit.
        
    case 'done'
        % Cleanup of plots, guis, or final plot
        
    otherwise
        
end

stop=false;

end

