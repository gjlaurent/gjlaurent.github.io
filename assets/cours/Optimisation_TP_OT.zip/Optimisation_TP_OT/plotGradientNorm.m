function stop = plotGradientNorm(X, optimValues, state)
% plotGradientNorm plots the relative gradient norm at each iteration:
%   norm(gradient(f(X_k)),inf)/(1+norm(gradient(f(X_0)),inf)).
%
%   Usage:
%     Create an options structure that will use plotGradientNorm as
%     the plot function:
%
%       options = optimset('PlotFcns',@plotGradientNorm);
%
%     Pass the options into an optimization problem to view the plot.

%   Copyright 2014 Guillaume Laurent

persistent initialGradient;

switch state
    
    case 'init'
        % Setup for plots or guis
        if isfield(optimValues,'gradient')
            initialGradient=norm(optimValues.gradient,inf);
            semilogy(optimValues.iteration,initialGradient/(1+initialGradient),'.r');
            xlabel('Iteration');
            ylabel('Relative Gradient Norm');
            set(gca,'YScale','log');
            grid on;
            hold on;
        end
        
    case 'iter'
        % Make updates to plot or guis as needed
        
        if isfield(optimValues,'gradient')
            relativeGradientNorm=norm(optimValues.gradient,inf)/(1+initialGradient);
            semilogy(optimValues.iteration,relativeGradientNorm,'.r');
            title(['Current Relative Gradient Norm: ' num2str(relativeGradientNorm)]);
        end
        
    case 'interrupt'
        % Probably no action here. Check conditions to see
        % whether optimization should quit.
        
    case 'done'
        % Cleanup of plots, guis, or final plot
        
    otherwise
        
end

stop=false;

end
