function stop = plotStructure(V, optimValues, state)

switch state
    case 'init'
        % Setup for plots or guis
        
    case 'iter'
        % Make updates to plot or guis as needed
        
        X=[V(1:2:length(V))  0  0  40 40];
        Y=[V(2:2:length(V)) 20  10 20 10];
        
        M=[0 1 0 1 1 0 1 1 0 0
            1 0 1 1 1 1 0 0 0 0
            0 1 0 0 1 1 0 0 1 1
            1 1 0 0 1 0 1 1 0 0
            1 1 1 1 0 1 0 0 0 0
            0 1 1 0 1 0 0 0 1 1
            1 0 0 1 0 0 0 0 0 0
            1 0 0 1 0 0 0 0 0 0
            0 0 1 0 0 1 0 0 0 0
            0 0 1 0 0 1 0 0 0 0];
        
        fillRectangle(-5,10,0,10,20,[.5 .5 .5]);
        axis([-10 50 0 40]);
        hold on;
        xlabel('x');
        ylabel('z');
        title('Current X Value');
        fillRectangle(45,10,0,10,20,[.5 .5 .5]);
        
        for i=1:1:10
            plot(X(i),Y(i),'b.');
            for j=i:1:10
                if M(i,j)==1
                    plot([X(i) X(j)],[Y(i) Y(j)]);
                end
            end
        end
        
        text(X(1),Y(1)+1,'1');
        text(X(2),Y(2)+1,'2');
        text(X(3),Y(3)+1,'3');
        text(X(4),Y(4)-1,'4');
        text(X(5),Y(5)-1,'5');
        text(X(6),Y(6)-1,'6');
        
        hold off;
        
    case 'interrupt'
        % Probably no action here. Check conditions to see
        % whether optimization should quit.
        
    case 'done'
        % Cleanup of plots, guis, or final plot
        
    otherwise
        
end

stop=false;

end

