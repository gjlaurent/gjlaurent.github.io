function stop = plotStepSize(X, optimValues, state)
% plotStepSize plots the norm of the difference of solution vector between 
%   two iterations: norm(X_k-X_{k-1}).
%
%   Usage: 
%     Create an options structure that will use plotStepSize as
%     the plot function:
%
%       options = optimset('PlotFcns',@plotStepSize);
%
%     Pass the options into an optimization problem to view the plot.

%   Copyright 2014 Guillaume Laurent

persistent previousX;

switch state
    case 'init'
          % Setup for plots or guis

          previousX=X;
          xlabel('Iteration');
          ylabel('Step Size');
          set(gca,'YScale','log'); 
          grid on;
          hold on;     
           
    case 'iter'
          % Make updates to plot or guis as needed
          
          semilogy(optimValues.iteration,norm(X-previousX),'.r');
          title(['Current Step Size: ' num2str(norm(X-previousX))]);
          previousX=X;
         
    case 'interrupt'
          % Probably no action here. Check conditions to see  
          % whether optimization should quit.

    case 'done'
          % Cleanup of plots, guis, or final plot

         
    otherwise
        
end

stop=false;

end
