function plotRessorts(X)

plot([0 1],[1 1],'k.');
axis([-0.5 1.5 0 2]);
xlabel('x');
ylabel('z');

hold on;
plot(X(1),X(2),'k.');
plot([0 X(1)],[1 X(2)],'r');
plot([1 X(1)],[1 X(2)],'r');
title(['Current X Value: [' num2str(X(1)) ' ' num2str(X(2)) ']']);
text(X(1)+0.05,X(2)-0.05,'m');
hold off;
drawnow;

end







