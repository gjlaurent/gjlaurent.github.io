function plotCouverture(V)

X=V(1:2:length(V));
Y=V(2:2:length(V));

figure(1);
img=imread('besancon.png');
image(img);
axis image; 
hold on;

load besancon.mat
plot(controlPointX,controlPointY,'w.');

plot(X,Y,'r.')
for i=1:1:length(X)
    plotCircle(X(i),Y(i),10,20,'r');
    plotCircle(X(i),Y(i),20,30,'r');
    plotCircle(X(i),Y(i),40,30,'r');
    set(text(X(i)+35,Y(i)+35,num2str(i)),'color','r');
end
title('Current X Value');
        
hold off;
drawnow;
