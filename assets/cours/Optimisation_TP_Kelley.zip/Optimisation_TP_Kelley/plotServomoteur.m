function plotServomoteur(X)

kp=X(1);
kd=X(2);

load_system('simServomoteur');
set_param('simServomoteur/Proportional Gain', 'Gain', num2str(kp) );
set_param('simServomoteur/Derivative Gain', 'Gain', num2str(kd) );

[time,states] = sim('simServomoteur');

J1=states(length(time),1);
J2=states(length(time),2)/1000;
position=states(:,3);

plot(time,position,'r');
grid on;
xlabel('Time');
ylabel('Position');
title(['Current X Value: [' num2str(kp) ' ' num2str(kd) '], J_1: ' num2str(J1) ', J_2: ' num2str(J2) ]);
drawnow;

end
