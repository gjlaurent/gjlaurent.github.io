function m=softmax(X,alpha)
% 
% Smooth approximation of maximum/minimum of X
% 
%     m=softmax(X,alpha)
%
% When alpha > 0, the function gives a smooth, differentiable 
% approximation of the maximum function
% When alpha < 0, the function gives a smooth, differentiable 
% approximation of the minimum function

e=exp(alpha*X);
m=sum(X.*e,2)./sum(e,2);