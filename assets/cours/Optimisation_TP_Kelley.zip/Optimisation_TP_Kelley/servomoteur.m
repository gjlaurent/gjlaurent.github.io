function [J,J1,J2]=servomoteur(X,alpha)

kp=X(1);
kd=X(2);

load_system('simServomoteur');
set_param('simServomoteur/Proportional Gain', 'Gain', num2str(kp) );
set_param('simServomoteur/Derivative Gain', 'Gain', num2str(kd) );

[time,states] = sim('simServomoteur');

J1=states(length(time),1);
J2=states(length(time),2)/1000;

J=(1-alpha)*J1+alpha*J2;

end