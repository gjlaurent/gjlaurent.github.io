function plotAjustement(X)

a=X(1);
b=X(2);
c=X(3);
d=X(4);

px=[300 312 324 345 365 367 378 382  390  397  401  412  423  445  458  467];
py=[804 791 796 805 815 796 879 940 1199 1439 1518 1587 1599 1596 1608 1601];

plot(px,py,'b+');
xlabel('x');
ylabel('y');
title(['Current X Value: y=' num2str(a) '+' num2str(b) '*tanh((x-' num2str(c) ')/' num2str(d) ')']);
grid on;
hold on;

x=300:0.1:500;
y=a+b*tanh((x-c)/d);

plot(x,y,'r');
hold off;
drawnow;

end