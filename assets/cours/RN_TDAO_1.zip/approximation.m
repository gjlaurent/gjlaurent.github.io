%-------------------------------------------------------------------
% lecture des donn�es d'apprentissage
load A_data.txt -ascii 
X=A_data(:,1);         % vecteur des observations en entr�e
Y=A_data(:,2);         % vecteur des observations en sortie
figure(1);
plot(X,Y,'+');         
xlabel('Entr�e X');
ylabel('Sortie Y');
title('Donn�es d''apprentissage');	

%-------------------------------------------------------------------
% Cr�ation du r�seau avec 1 neurone d'entr�e, 2 neurones cach�s 
% et 1 neurone de sortie lin�aire
net = mlp(1,2, 1, 'linear');                            

%-------------------------------------------------------------------
% R�glages des options de l'algorithme d'optimisation
options = zeros(1,18); % vecteur nul de taille 18
options(1) = 1;        % affiche l'erreur totale � chaque it�ration
options(14) = 10;      % nombre maximum d'it�rations 

%-------------------------------------------------------------------
% Optimisation avec un algorithme quasi-newton
[net, options, errors] = netopt(net, options, X, Y, 'quasinew');

%-------------------------------------------------------------------
% Affichage du crit�re des moindres carr�s en fonction des it�rations
figure(2);        
semilogy(errors);
xlabel('It�rations');
ylabel('Crit�re des moindres carr�s');
title('Optimisation des poids du r�seau');	

%-------------------------------------------------------------------
% Comparaison de la sortie du r�seau et des donn�es
figure(3);           
XT=[-2:0.01:2]';     % vecteur d'entr�e de test
YT=mlpfwd(net,XT);   % calcul de la sortie de test
plot(X,Y,'+',XT,YT);
xlabel('Entr�e X');
ylabel('Sortie Y');
title('Comparaison de la sortie du r�seau avec les donn�es');	

%-------------------------------------------------------------------
% Calcul de la valeur finale du crit�re des moindres carr�s pour les 
% donn�es d'apprentissage
Crit_data=mlperr(net,X,Y)
