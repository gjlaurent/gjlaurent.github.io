%-------------------------------------------------------------------
% lecture des donn�es de validation
load A_valid.txt -ascii 
XV=A_valid(:,1);         % vecteur des observations en entr�e
YV=A_valid(:,2);         % vecteur des observations en sortie


%-------------------------------------------------------------------
% Comparaison de la sortie du r�seau et des donn�es
figure(4);           
plot(X,Y,'+',XT,YT,XV,YV,'r+');
xlabel('Entr�e X');
ylabel('Sortie Y');
title('Comparaison de la sortie du r�seau avec les donn�es');
legend('Donn�es d''apprentissage','Sortie du r�seau','Donn�es de validation',2);

%-------------------------------------------------------------------
% Calcul de la valeur finale du crit�re des moindres carr�s pour les 
% donn�es de validation
Crit_valid=mlperr(net,XV,YV)
