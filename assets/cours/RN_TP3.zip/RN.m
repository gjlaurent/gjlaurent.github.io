function [NetDef,W1,W2]=RN(ne,nc,ns)
%
% Cr�e les variables d'un r�seau de neurones non boucl�
% pour la toolbox nnsysid
%
% Emploi : >>[NetDef,W1,W2]=RN(ne,nc,ns);
%
% Entr�es :
%
%   ne : nombre de neurones d'entr�e
%   nc : nombre de neurones cach�s (tanh)
%   ns : nombre de neuroned de sortie (lin�aire)
%
% Sorties :
%
%   NetDef : structure du r�seau
%   W1     : poids des connexions entr�e->cach�e
%            matrice de dimension nc par (ne+1)
%   W2     : poids des connexions cach�e->sortie
%            matrice de dimension ns par (nc+1)

W1=rand(nc,ne+1);
W2=rand(ns,nc+1);

sc='H';
ss='L';

for i=2:nc,
     sc=[sc 'H'];
     ss=[ss '-'];
end

NetDef = [sc
          ss]; 
