% Exemple d'utilisation de la toolbox nnsysid pour l'approximation de courbe

% Chargement des donn�es 
%  x : entr�es
%  y : sorties
%  y_val : sorties (de validation)
load approx.mat

figure;
plot(x,y,'x',x,y_val,'x');

% Cr�ation du r�seau
[NetDef,W1,W2]=RN(1,6,1);

% R�glages des options des algorithmes d'optimisation
trparms=settrain;                        % options par d�faut
trparms=settrain(trparms,'maxiter',100); % Nombre maximum d'it�rations 

% Optimisation avec l'algorithme de gradient simple
[W1,W2,critvec]=batbp(NetDef,W1,W2,x,y,trparms);

% Optimisation avec l'algorithme de Levenberg-Marquardt (second ordre)
%[W1,W2,critvec]=marq(NetDef,W1,W2,x,y,trparms);

% Affichage de l'erreur en fonction des it�rations
figure;
semilogy(critvec);
xlabel('It�ration');
ylabel('Crit�re total');

% Comparaison de la sortie du r�seau et des donn�es
yhat = nneval(NetDef,W1,W2,x,y);


