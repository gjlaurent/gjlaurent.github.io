%-------------------------------------------------------------------
% lecture des donn�es d'apprentissage
load pendigits_data.txt -ascii 
X=pendigits_data(:,1:16); % vecteur des observations en entr�e
Y=pendigits_data(:,17);   % vecteur des observations en sortie

num_ligne=1; % Indice de la ligne � visualiser

plot(X(num_ligne,1:2:16),X(num_ligne,2:2:16),'ob-');
title(['Trac� du chiffre ' num2str(Y(num_ligne))]);

