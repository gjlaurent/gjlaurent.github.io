%-------------------------------------------------------------------
% lecture des donn�es de validation
load pendigits_valid.txt -ascii 
XV=pendigits_valid(:,1:16); % vecteur des observations en entr�e
YV=pendigits_valid(:,17);   % vecteur des observations en sortie

%-------------------------------------------------------------------
% pr�paration des donn�es
XV=XV/50-1; % les entr�es sont norm�es et centr�es
YV=(YV==3); % les sorties valent 1 pour le chiffre 3, 0 pour les 
            % autres chiffres

%-------------------------------------------------------------------
% Calcul de la valeur finale du crit�re des moindres carr�s pour les 
% donn�es de validation
Crit_valid=mlperr(net,XV,YV);
disp('--------------------------------------------------');
disp(['Valeur du crit�re (valid) :              ' num2str(Crit_valid)]);

%-------------------------------------------------------------------
% Comparaison de la sortie du r�seau et des donn�es
YVR=mlpfwd(net,XV)>0.5; % Calcul de la sortie et seuillage � 0.5
Nb_detection=sum(and(YVR,YV));
Nb_non_detection=sum(YV)-Nb_detection;
Nb_fausse_detection=sum(YVR)-Nb_detection;
disp(['Nombre de d�tections correctes (valid) : ' num2str(Nb_detection)]);
disp(['Nombre de non d�tections (valid) :       ' num2str(Nb_non_detection)]);
disp(['Nombre de fausses d�tections (valid) :   ' num2str(Nb_fausse_detection)]);

