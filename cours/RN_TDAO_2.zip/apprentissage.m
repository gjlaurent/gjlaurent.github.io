%-------------------------------------------------------------------
% lecture des donn�es d'apprentissage
load pendigits_data.txt -ascii 
X=pendigits_data(:,1:16); % vecteur des observations en entr�e
Y=pendigits_data(:,17);   % vecteur des observations en sortie

%-------------------------------------------------------------------
% pr�paration des donn�es
X=X/50-1; % les entr�es sont norm�es et centr�es
Y=(Y==3); % les sorties valent 1 pour le chiffre 3, 0 pour les 
          % autres chiffres

%-------------------------------------------------------------------
% Cr�ation du r�seau avec ? neurones d'entr�e, ? neurones cach�s 
% et 1 neurone de sortie avec la fonction logistique
net = mlp(?,?, 1, 'logistic');                            

%-------------------------------------------------------------------
% R�glages des options de l'algorithme d'optimisation
options = zeros(1,18); % vecteur nul de taille 18
options(1) = 1;        % affiche l'erreur totale � chaque it�ration
options(14) = ?;       % nombre maximum d'it�rations 

%-------------------------------------------------------------------
% Optimisation avec un algorithme quasi-newton
[net, options, errors] = netopt(net, options, X, Y, 'scg');

%-------------------------------------------------------------------
% Affichage du crit�re des moindres carr�s en fonction des it�rations
figure(1);        
semilogy(errors);
xlabel('It�rations');
ylabel('Crit�re des moindres carr�s');
title('Optimisation des poids du r�seau');	

%-------------------------------------------------------------------
% Calcul de la valeur finale du crit�re des moindres carr�s pour les 
% donn�es d'apprentissage
Crit_data=mlperr(net,X,Y);
disp('--------------------------------------------------');
disp(['Valeur du crit�re (data) :              ' num2str(Crit_data)]);

%-------------------------------------------------------------------
% Comparaison de la sortie du r�seau et des donn�es
YR=mlpfwd(net,X)>0.5; % Calcul de la sortie et seuillage � 0.5
Nb_detection=sum(and(YR,Y));
Nb_non_detection=sum(Y)-Nb_detection;
Nb_fausse_detection=sum(YR)-Nb_detection;
disp(['Nombre de d�tections correctes (data) : ' num2str(Nb_detection)]);
disp(['Nombre de non d�tections (data) :       ' num2str(Nb_non_detection)]);
disp(['Nombre de fausses d�tections (data) :   ' num2str(Nb_fausse_detection)]);

